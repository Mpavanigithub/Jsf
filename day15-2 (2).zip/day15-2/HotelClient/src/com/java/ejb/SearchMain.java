package com.java.ejb;

import java.sql.SQLException;
import java.util.Scanner;

import javax.naming.InitialContext;
import javax.naming.NamingException;

public class SearchMain {
	
	public static void main(String[] args) throws NamingException, ClassNotFoundException, SQLException {
		String hotelId;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter hotelId ");
		hotelId = sc.next();
		 HotelBeanRemote service = null;
		    service = (HotelBeanRemote)
		    		new InitialContext().lookup("HotelBean/remote");
		HotelDetails hotel = service.searchHotelDetailsBean(hotelId);
		if(hotel!=null){
			System.out.println(hotel);
		}
		else {
			System.out.println("File not found ...");
		}
	}

}
