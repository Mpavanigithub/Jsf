package com.java.ejb;

import java.sql.SQLException;
import java.util.Scanner;

import javax.naming.InitialContext;
import javax.naming.NamingException;

public class AddHotelMain {
	
	
	public static void main(String[] args) throws NamingException, ClassNotFoundException, SQLException {
		Scanner sc  = new Scanner(System.in);
	     HotelDetails hotel = new  HotelDetails();
	     System.out.println("Enter Hotel Name ");
	     hotel.setHotelName(sc.next());
	     System.out.println("Enter Hotel Address1");
	     hotel.setAddress1(sc.next());
	     System.out.println("Enter Hotel Address2");
	     hotel.setAddress2(sc.next());
	     System.out.println("Enter Hotel City ");
	     hotel.setCity(sc.next());
	     System.out.println("Enter ZipCode ");
	     hotel.setZipcode(sc.next());
	     System.out.println("Enter contactNO ");
	     hotel.setContactNo(sc.next());
	     System.out.println("Enter Rating ");
	     hotel.setRating(sc.nextDouble());
	     System.out.println("Enter Review");
	     hotel.setReview(sc.next());
	     System.out.println("Enter Aboutus " );
	     hotel.setAboutus(sc.next());
	     
	     
	     HotelBeanRemote service = null;
		    service = (HotelBeanRemote)
		    		new InitialContext().lookup("HotelBean/remote");
		    System.out.println(service.addhotelDetailsBean(hotel));
			
		
	}

}
