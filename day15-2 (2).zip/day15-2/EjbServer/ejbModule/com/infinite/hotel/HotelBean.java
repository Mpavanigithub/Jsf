package com.infinite.hotel;

import java.sql.SQLException;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Remote;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class HotelBean
 */
@Stateless
@Remote(HotelBeanRemote.class)

public class HotelBean implements HotelBeanRemote {

static HotelDAO hdao;
	
	static {
		hdao = new HotelDAO();
	}
	
    /**
     * Default constructor. 
     */
    public HotelBean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public List<HotelDetails> showHotelDetailsBean() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		return hdao.showHotelDetails();
	}

	@Override
	public HotelDetails searchHotelDetailsBean(String hotelId) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		return hdao.searcHotelDetails(hotelId);
	}

	@Override
	public String addhotelDetailsBean(HotelDetails hotel) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		return hdao.addhotelDetails(hotel);
	}

	

	
	

}
