package com.infinite.hotel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class HotelDAO {
	
	Connection connection;
	PreparedStatement pst;

	public HotelDetails searcHotelDetails(String hotelId) throws ClassNotFoundException, SQLException{
		connection = ConnectionHelper.getConnection();
		String cmd="select * from HotelDetails where hotelId=?";
		pst = connection.prepareStatement(cmd);
		pst.setString(1, hotelId);
		ResultSet rs = pst.executeQuery();
		HotelDetails hotel =null;
		if(rs.next()){
			hotel = new HotelDetails();
			hotel.setHotelId(rs.getString("hotelId"));
			hotel.setHotelName(rs.getString("hotelName"));
			hotel.setAddress1(rs.getString("address1"));
			hotel.setAddress2(rs.getString("address2"));
			hotel.setCity(rs.getString("city"));
			hotel.setContactNo(rs.getString("contactNo"));
			hotel.setZipcode(rs.getString("zipcode"));
			hotel.setRating(rs.getInt("rating"));
			hotel.setReview(rs.getString("review"));
			hotel.setAboutus(rs.getString("aboutus"));
			
		}
		return hotel;
		
		
		
	}
	public String generateHotelId() throws ClassNotFoundException, SQLException  {
        connection = ConnectionHelper.getConnection();
        String cmd = "select case when max(hotelId) is NULL THEN 'H001' else max(hotelId) end  hid from HotelDetails";
        pst = connection.prepareStatement(cmd);
        ResultSet rs = pst.executeQuery();
        rs.next();
        String rid = rs.getString("hid");
        int id = Integer.parseInt(rid.substring(1));
        id++;
        String hid="";
        if (id >=0 && id <=9) {
            hid="H00"+id;
        }
        if (id >=10 && id <= 99) {
            hid="H0"+id;
        }
        if (id >=100 && id<=999) {
            hid="H"+id;
        }
        return hid;
    }
		
	public String addhotelDetails(HotelDetails hotel) throws ClassNotFoundException, SQLException{
		
		connection = ConnectionHelper.getConnection();
		String s = generateHotelId();
		
		String cmd = "insert into HotelDetails(hotelId,hotelName,address1,address2,city,zipcode,contactNo,rating,review,aboutus)"
				+"values(?,?,?,?,?,?,?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setString(1, s);
		pst.setString(2, hotel.getHotelName());
		pst.setString(3, hotel.getAddress1());
		pst.setString(4, hotel.getAddress2());
		pst.setString(5, hotel.getCity());
		pst.setString(6, hotel.getZipcode());
		pst.setString(7, hotel.getContactNo());
		pst.setDouble(8, hotel.getRating());
		pst.setString(9, hotel.getReview());
		pst.setString(10, hotel.getAboutus());
		
		pst.executeUpdate();
		return "Hotel Added Successfully..";
		
		
	}
	
	
	
	
	public List<HotelDetails>  showHotelDetails() throws SQLException, ClassNotFoundException{
		List<HotelDetails>  hotelList = new ArrayList<HotelDetails>();
		connection = ConnectionHelper.getConnection();
		String cmd = "select *from HotelDetails";
		
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		HotelDetails hotel =null;
		while(rs.next()){
			hotel = new HotelDetails();
			
			hotel.setHotelId(rs.getString("hotelId"));
			hotel.setHotelName(rs.getString("hotelName"));
			hotel.setAddress1(rs.getString("address1"));
			hotel.setAddress2(rs.getString("address2"));
			hotel.setCity(rs.getString("city"));
			hotel.setZipcode(rs.getString("zipcode"));
			hotel.setContactNo(rs.getString("contactNo"));
			hotel.setRating(rs.getInt("rating"));
			hotel.setReview(rs.getString("review"));
			hotel.setAboutus(rs.getString("aboutus"));
			
			hotelList.add(hotel);
		}
		return hotelList;
			
		}
		
	
	
	
}
